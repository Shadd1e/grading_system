/**
 * Node.js backend — the "coordination" layer described in your thesis
 * (Chapter 3): handles requests from the frontend, forwards them to the
 * Python ML service, and returns the result. Auth/its own database can be
 * layered in later; this is a thin, working pass-through.
 *
 * Usage:
 *   node index.js
 * (defaults to port 4000; set PORT env var to change)
 *
 * Requires the Python ML service to already be running separately
 * (uvicorn app.main:app --reload, from ml-service/), reachable at
 * ML_SERVICE_URL below.
 */
const express = require("express");
const multer = require("multer");
const cors = require("cors");

const app = express();
const upload = multer({ storage: multer.memoryStorage() });

const PORT = process.env.PORT || 4000;
const ML_SERVICE_URL = process.env.ML_SERVICE_URL || "http://127.0.0.1:8000";

app.use(cors());
app.use(express.json());

// Small helper: forward a JSON request to the ML service and relay
// whatever it responds with (status code included), rather than masking
// real errors (missing exam, validation failure, etc.) with a generic 500.
async function forwardJson(method, path, body, res) {
  try {
    const mlResponse = await fetch(`${ML_SERVICE_URL}${path}`, {
      method,
      headers: body ? { "Content-Type": "application/json" } : undefined,
      body: body ? JSON.stringify(body) : undefined,
    });
    const data = await mlResponse.json();
    res.status(mlResponse.status).json(data);
  } catch (err) {
    res.status(502).json({
      error: `Failed to reach ML service at ${ML_SERVICE_URL}. Is uvicorn running?`,
      details: err.message,
    });
  }
}

// --- Health check: confirms both this server AND the Python ML service are up ---
app.get("/api/health", async (req, res) => {
  try {
    const mlResponse = await fetch(`${ML_SERVICE_URL}/health`);
    const mlHealth = await mlResponse.json();
    res.json({
      backend_status: "ok",
      ml_service_reachable: true,
      ml_service: mlHealth,
    });
  } catch (err) {
    res.status(503).json({
      backend_status: "ok",
      ml_service_reachable: false,
      error: `Could not reach ML service at ${ML_SERVICE_URL}. Is uvicorn running? (${err.message})`,
    });
  }
});

// --- Templates: the 3 answer-sheet layouts the Exam Builder can choose from ---
app.get("/api/templates", (req, res) => forwardJson("GET", "/templates", null, res));

// --- Exams: create / list / fetch, and download the question paper PDF ---
app.post("/api/exams", (req, res) => forwardJson("POST", "/exams", req.body, res));
app.get("/api/exams", (req, res) => forwardJson("GET", "/exams", null, res));
app.get("/api/exams/:examId", (req, res) =>
  forwardJson("GET", `/exams/${encodeURIComponent(req.params.examId)}`, null, res)
);

app.get("/api/exams/:examId/question-paper.pdf", async (req, res) => {
  try {
    const mlResponse = await fetch(
      `${ML_SERVICE_URL}/exams/${encodeURIComponent(req.params.examId)}/question-paper.pdf`
    );
    if (!mlResponse.ok) {
      const data = await mlResponse.json();
      return res.status(mlResponse.status).json(data);
    }
    res.setHeader("Content-Type", "application/pdf");
    const buffer = Buffer.from(await mlResponse.arrayBuffer());
    res.send(buffer);
  } catch (err) {
    res.status(502).json({
      error: `Failed to reach ML service at ${ML_SERVICE_URL}. Is uvicorn running?`,
      details: err.message,
    });
  }
});

// --- Answer sheets: static blank PDF per template type ---
app.get("/api/answer-sheets/:templateType", async (req, res) => {
  try {
    const mlResponse = await fetch(
      `${ML_SERVICE_URL}/answer-sheets/${encodeURIComponent(req.params.templateType)}.pdf`
    );
    if (!mlResponse.ok) {
      const data = await mlResponse.json();
      return res.status(mlResponse.status).json(data);
    }
    res.setHeader("Content-Type", "application/pdf");
    const buffer = Buffer.from(await mlResponse.arrayBuffer());
    res.send(buffer);
  } catch (err) {
    res.status(502).json({
      error: `Failed to reach ML service at ${ML_SERVICE_URL}. Is uvicorn running?`,
      details: err.message,
    });
  }
});

// --- Grade a script: receives the uploaded image from the frontend, ---
// --- forwards it to the Python ML service's /grade-script endpoint  ---
app.post("/api/grade-script", upload.single("file"), async (req, res) => {
  if (!req.file) {
    return res.status(400).json({ error: "No file uploaded. Expected a form field named 'file'." });
  }

  const { exam_id, answer_key_path, student_id } = req.body;
  if (!exam_id && !answer_key_path) {
    return res.status(400).json({ error: "Provide either 'exam_id' or 'answer_key_path'." });
  }

  try {
    // Build a multipart form to forward to the Python service, using
    // Node's built-in fetch/FormData/Blob (no extra dependency needed —
    // available natively from Node 18+).
    const forwardForm = new FormData();
    forwardForm.append(
      "file",
      new Blob([req.file.buffer], { type: req.file.mimetype }),
      req.file.originalname
    );
    if (exam_id) forwardForm.append("exam_id", exam_id);
    if (answer_key_path) forwardForm.append("answer_key_path", answer_key_path);
    if (student_id) forwardForm.append("student_id", student_id);

    const mlResponse = await fetch(`${ML_SERVICE_URL}/grade-script`, {
      method: "POST",
      body: forwardForm,
    });

    const result = await mlResponse.json();

    if (!mlResponse.ok) {
      return res.status(mlResponse.status).json(result);
    }

    res.json(result);
  } catch (err) {
    res.status(502).json({
      error: `Failed to reach ML service at ${ML_SERVICE_URL}. Is uvicorn running?`,
      details: err.message,
    });
  }
});

// --- Results: list past graded scripts, fetch one in full, review a flagged item ---
app.get("/api/results", (req, res) => forwardJson("GET", "/results", null, res));
app.get("/api/results/:resultId", (req, res) =>
  forwardJson("GET", `/results/${encodeURIComponent(req.params.resultId)}`, null, res)
);
app.post("/api/results/:resultId/review", (req, res) =>
  forwardJson("POST", `/results/${encodeURIComponent(req.params.resultId)}/review`, req.body, res)
);

app.listen(PORT, () => {
  console.log(`Backend listening on http://localhost:${PORT}`);
  console.log(`Forwarding requests to ML service at ${ML_SERVICE_URL}`);
});
