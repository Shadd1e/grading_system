"""
Inference wrapper around a fine-tuned TrOCR model, used by the FastAPI app.

Confidence scoring note: TrOCR is a generative sequence model, so it doesn't
give a single clean "confidence" the way a classifier does. We approximate
one by taking the mean per-token probability of the generated sequence
(via output_scores from generate()). This is a reasonable proxy for
"how sure was the model of what it produced", consistent with how confidence
thresholds are used in comparable systems (Lu, Zhou, & Ji, 2021).
"""
from pathlib import Path
from typing import Optional, Tuple

import numpy as np
import torch
import torch.nn.functional as F
from PIL import Image
from transformers import TrOCRProcessor, VisionEncoderDecoderModel


class PhraseRecognizer:
    def __init__(self, model_path: str, device: Optional[str] = None):
        self.device = torch.device(
            device or ("cuda" if torch.cuda.is_available() else "cpu")
        )
        self.processor = TrOCRProcessor.from_pretrained(model_path)
        self.model = VisionEncoderDecoderModel.from_pretrained(model_path).to(self.device)
        self.model.eval()

    @torch.no_grad()
    def predict(self, gray_image: np.ndarray, max_length: int = 24) -> Tuple[str, float]:
        """gray_image: single-channel numpy array (as produced by segment.py).
        Returns (recognised_text, confidence in [0, 1])."""
        rgb_image = Image.fromarray(gray_image).convert("RGB")
        pixel_values = self.processor(rgb_image, return_tensors="pt").pixel_values.to(self.device)

        outputs = self.model.generate(
            pixel_values,
            max_length=max_length,
            output_scores=True,
            return_dict_in_generate=True,
        )

        generated_ids = outputs.sequences
        text = self.processor.batch_decode(generated_ids, skip_special_tokens=True)[0].strip()

        # Mean of the max softmax probability at each generation step, as a
        # rough per-sequence confidence estimate.
        if outputs.scores:
            step_confidences = []
            for step_logits in outputs.scores:
                probs = F.softmax(step_logits, dim=-1)
                step_confidences.append(probs.max(dim=-1).values.mean().item())
            confidence = float(np.mean(step_confidences)) if step_confidences else 0.0
        else:
            confidence = 0.0

        return text, confidence


def load_recognizer(model_path: str = "./checkpoints/trocr_finetuned") -> Optional["PhraseRecognizer"]:
    """Returns None (rather than raising) if no fine-tuned model has been
    saved yet, so the FastAPI app can start and report a clear error instead
    of crashing before Iteration 2 is done."""
    if not Path(model_path).exists():
        return None
    return PhraseRecognizer(model_path)
