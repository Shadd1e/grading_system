"""
FastAPI service — the single entry point the Node.js backend (or, for now,
you via curl/Postman/the /docs page/the frontend) talks to.

Endpoints:
  GET  /health                          - service + model status
  GET  /templates                       - list the 3 answer-sheet layouts
  POST /exams                           - create an exam (questions + answers)
  GET  /exams                           - list saved exams
  GET  /exams/{exam_id}                 - full exam content
  GET  /exams/{exam_id}/question-paper.pdf - download the student-facing PDF
  GET  /answer-sheets/{template_type}.pdf  - download the blank answer sheet
                                              for a given layout
  POST /grade-script                    - grade a scanned script
  GET  /results                         - list past graded scripts
  GET  /results/{result_id}             - full detail of one graded script
  POST /results/{result_id}/review      - lecturer confirms/corrects a
                                           flagged answer

Everything under data/exams/ and data/results/ persists to disk as JSON, so
results survive server restarts (unlike the previous in-memory-only store).

Run with:
    uvicorn app.main:app --reload --port 8000
Then open http://localhost:8000/docs for an interactive test UI.
"""
import json
import uuid
from datetime import datetime, timezone
from pathlib import Path
from typing import Optional, Union, Literal, Annotated

import cv2
import numpy as np
from fastapi import FastAPI, UploadFile, File, HTTPException, Form
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import FileResponse
from pydantic import BaseModel, Field

from app.preprocessing.segment import load_template, process_answer_sheet
from app.mcq_model.infer import load_recognizer as load_mcq_recognizer
from app.phrase_model.infer import load_recognizer as load_phrase_recognizer
from app.grading.engine import grade_script
from app.exam_content import (
    validate_against_template,
    derive_answer_key,
    generate_question_paper_pdf,
)

DATA_DIR = Path(__file__).resolve().parents[1] / "data"
TEMPLATES_DIR = DATA_DIR / "templates"
ANSWER_SHEETS_DIR = DATA_DIR / "answer_sheets"
EXAMS_DIR = DATA_DIR / "exams"
RESULTS_DIR = DATA_DIR / "results"
# NOTE: these match where the training scripts save by DEFAULT when run
# from inside ml-service/training/ (e.g. `cd training && python train_mcq_cnn.py`).
# If you passed a custom --output path when training, update these to match.
MCQ_CHECKPOINT = Path(__file__).resolve().parents[1] / "training" / "checkpoints" / "mcq_cnn.pt"
TROCR_CHECKPOINT = Path(__file__).resolve().parents[1] / "training" / "checkpoints" / "trocr_finetuned"

TEMPLATE_TYPES = ["mixed", "all_mcq", "all_completion"]
TEMPLATE_LABELS = {
    "mixed": "Mixed (5 Multiple Choice + 5 Short Answer)",
    "all_mcq": "All Multiple Choice (10 questions)",
    "all_completion": "All Short Answer (10 questions)",
}

app = FastAPI(title="Handwriting Grading Assistant — ML Service")

# Loosen CORS for local development. Tighten this before any real deployment.
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_methods=["*"],
    allow_headers=["*"],
)

# Templates + models are loaded once at startup and reused across requests.
# mcq_recognizer / phrase_recognizer will be None until you've actually run
# the training scripts and produced a checkpoint — endpoints check for this
# and return a clear error rather than crashing.
templates = {
    t: load_template(str(TEMPLATES_DIR / t / "template.json")) for t in TEMPLATE_TYPES
}
mcq_recognizer = load_mcq_recognizer(str(MCQ_CHECKPOINT))
phrase_recognizer = load_phrase_recognizer(str(TROCR_CHECKPOINT))


# --------------------------------------------------------------------------
# Request/response models
# --------------------------------------------------------------------------
class MCQQuestionIn(BaseModel):
    type: Literal["mcq"]
    text: str
    options: dict[str, str]
    correct: str


class PhraseQuestionIn(BaseModel):
    type: Literal["phrase"]
    text: str
    acceptable_answers: list[str]


QuestionIn = Annotated[Union[MCQQuestionIn, PhraseQuestionIn], Field(discriminator="type")]


class ExamCreateRequest(BaseModel):
    exam_id: str
    template_type: Literal["mixed", "all_mcq", "all_completion"] = "mixed"
    course_code: str
    course_title: str
    instructions: str = (
        "Answer ALL questions. Write your answers in the correspondingly "
        "numbered box on the structured answer sheet provided."
    )
    max_score_mcq: float = 2
    max_score_phrase: float = 5
    confidence_threshold: float = 0.75
    questions: dict[str, QuestionIn]


class ReviewUpdate(BaseModel):
    question_id: str
    corrected_score: float
    corrected_text: Optional[str] = None


# --------------------------------------------------------------------------
# Health
# --------------------------------------------------------------------------
@app.get("/health")
def health_check():
    return {
        "status": "ok",
        "mcq_model_loaded": mcq_recognizer is not None,
        "phrase_model_loaded": phrase_recognizer is not None,
    }


@app.get("/templates")
def list_templates():
    """Exposes each template type's question IDs + types (not the pixel
    coordinates) so the frontend's Exam Builder can let the lecturer pick a
    layout and generate exactly the right question slots for it — this is
    what prevents a mismatched exam from ever being created in the first
    place, rather than catching it after submission."""
    return [
        {
            "type": t,
            "label": TEMPLATE_LABELS[t],
            "questions": [
                {"id": q["id"], "type": q["type"]} for q in templates[t]["questions"]
            ],
        }
        for t in TEMPLATE_TYPES
    ]


# --------------------------------------------------------------------------
# Exams: create/list questions + correct answers, generate the question
# paper PDF and answer key. This is what the frontend's "Exams" page calls,
# so the lecturer never has to hand-edit JSON or run a script.
# --------------------------------------------------------------------------
@app.post("/exams")
def create_exam(exam: ExamCreateRequest):
    exam_dict = exam.model_dump()
    chosen_template = templates[exam.template_type]

    try:
        validate_against_template(exam_dict, chosen_template)
    except ValueError as e:
        raise HTTPException(status_code=400, detail=str(e))

    exam_dir = EXAMS_DIR / exam.exam_id
    exam_dir.mkdir(parents=True, exist_ok=True)

    with open(exam_dir / "exam_content.json", "w") as f:
        json.dump(exam_dict, f, indent=2)

    answer_key = derive_answer_key(exam_dict)
    with open(exam_dir / "answer_key.json", "w") as f:
        json.dump(answer_key, f, indent=2)

    generate_question_paper_pdf(exam_dict, str(exam_dir / "question_paper.pdf"))

    return {
        "exam_id": exam.exam_id,
        "template_type": exam.template_type,
        "course_code": exam.course_code,
        "course_title": exam.course_title,
        "question_count": len(exam.questions),
        "question_paper_url": f"/exams/{exam.exam_id}/question-paper.pdf",
        "answer_sheet_url": f"/answer-sheets/{exam.template_type}.pdf",
    }


@app.get("/exams")
def list_exams():
    if not EXAMS_DIR.exists():
        return []
    exams = []
    for exam_dir in sorted(EXAMS_DIR.iterdir()):
        content_path = exam_dir / "exam_content.json"
        if not content_path.exists():
            continue
        with open(content_path) as f:
            content = json.load(f)
        exams.append({
            "exam_id": content["exam_id"],
            "template_type": content.get("template_type", "mixed"),
            "course_code": content["course_code"],
            "course_title": content["course_title"],
            "question_count": len(content["questions"]),
        })
    return exams


@app.get("/exams/{exam_id}")
def get_exam(exam_id: str):
    content_path = EXAMS_DIR / exam_id / "exam_content.json"
    if not content_path.exists():
        raise HTTPException(status_code=404, detail=f"No exam with id '{exam_id}'")
    with open(content_path) as f:
        return json.load(f)


@app.get("/exams/{exam_id}/question-paper.pdf")
def get_question_paper(exam_id: str):
    pdf_path = EXAMS_DIR / exam_id / "question_paper.pdf"
    if not pdf_path.exists():
        raise HTTPException(status_code=404, detail=f"No question paper for exam '{exam_id}'")
    return FileResponse(
        str(pdf_path), media_type="application/pdf", filename=f"{exam_id}_question_paper.pdf"
    )


@app.get("/answer-sheets/{template_type}.pdf")
def get_answer_sheet(template_type: str):
    """The blank, printable answer sheet for a given template type. This is
    a static, pre-generated file — the SAME sheet is reused for every exam
    built on that template, since the sheet has no question text on it (see
    generate_template_pdf.py); only the accompanying question paper is
    exam-specific."""
    if template_type not in TEMPLATE_TYPES:
        raise HTTPException(
            status_code=404,
            detail=f"Unknown template type '{template_type}'. Valid types: {TEMPLATE_TYPES}",
        )
    pdf_path = ANSWER_SHEETS_DIR / f"{template_type}_answer_sheet.pdf"
    if not pdf_path.exists():
        raise HTTPException(status_code=404, detail=f"No answer sheet file found for '{template_type}'")
    return FileResponse(
        str(pdf_path), media_type="application/pdf", filename=f"{template_type}_answer_sheet.pdf"
    )


# --------------------------------------------------------------------------
# Grading + persisted results
# --------------------------------------------------------------------------
def _save_result(result: dict) -> None:
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    with open(RESULTS_DIR / f"{result['result_id']}.json", "w") as f:
        json.dump(result, f, indent=2)


def _load_result(result_id: str) -> Optional[dict]:
    path = RESULTS_DIR / f"{result_id}.json"
    if not path.exists():
        return None
    with open(path) as f:
        return json.load(f)


@app.post("/grade-script")
async def grade_script_endpoint(
    file: UploadFile = File(...),
    exam_id: Optional[str] = Form(
        None, description="Exam id created via POST /exams — preferred over answer_key_path"
    ),
    answer_key_path: Optional[str] = Form(
        None, description="Direct path to an answer_key JSON file (manual/legacy use)"
    ),
    student_id: Optional[str] = Form(None),
):
    if mcq_recognizer is None:
        raise HTTPException(
            status_code=503,
            detail=(
                "MCQ model not loaded. Train it first: "
                "cd training && python train_mcq_cnn.py --epochs 10 — "
                f"then confirm a checkpoint exists at {MCQ_CHECKPOINT}"
            ),
        )
    if phrase_recognizer is None:
        print(
            "NOTE: no fine-tuned TrOCR model found — short-phrase questions "
            "will be flagged for manual review instead of auto-recognised."
        )

    if exam_id:
        exam_dir = EXAMS_DIR / exam_id
        key_path = exam_dir / "answer_key.json"
        content_path = exam_dir / "exam_content.json"
        if not key_path.exists():
            raise HTTPException(
                status_code=400,
                detail=f"No exam with id '{exam_id}'. Create it first via POST /exams.",
            )
        with open(content_path) as f:
            exam_template_type = json.load(f).get("template_type", "mixed")
        script_template = templates[exam_template_type]
    elif answer_key_path:
        key_path = Path(answer_key_path)
        if not key_path.exists():
            raise HTTPException(status_code=400, detail=f"Answer key not found at {answer_key_path}")
        # Legacy/manual path — no exam record to look up a template type from,
        # so fall back to the original default layout.
        script_template = templates["mixed"]
    else:
        raise HTTPException(status_code=400, detail="Provide either 'exam_id' or 'answer_key_path'.")

    with open(key_path) as f:
        answer_key = json.load(f)

    image_bytes = await file.read()
    np_array = np.frombuffer(image_bytes, dtype=np.uint8)
    image = cv2.imdecode(np_array, cv2.IMREAD_COLOR)
    if image is None:
        raise HTTPException(status_code=400, detail="Could not decode uploaded image.")

    try:
        boxes = process_answer_sheet(image, script_template)
    except ValueError as e:
        raise HTTPException(status_code=422, detail=str(e))

    recognized_answers = {}
    for box in boxes:
        if box.type == "mcq":
            text, confidence = mcq_recognizer.predict(box.image)
        elif phrase_recognizer is not None:
            text, confidence = phrase_recognizer.predict(box.image)
        else:
            text, confidence = "", 0.0
        recognized_answers[box.id] = {"text": text, "confidence": confidence}

    script_result = grade_script(recognized_answers, answer_key, student_id=student_id)

    result_id = uuid.uuid4().hex[:12]
    result = {
        "result_id": result_id,
        "student_id": student_id,
        "exam_id": exam_id or answer_key.get("answer_key_id"),
        "graded_at": datetime.now(timezone.utc).isoformat(),
        "answer_key_id": script_result.answer_key_id,
        "total_score": script_result.total_score,
        "max_possible_score": script_result.max_possible_score,
        "pending_review_count": script_result.pending_review_count,
        "questions": [
            {
                "question_id": r.question_id,
                "type": r.type,
                "recognized_text": r.recognized_text,
                "confidence": r.confidence,
                "score": r.score,
                "max_score": r.max_score,
                "flagged_for_review": r.flagged_for_review,
                "reviewed": r.reviewed,
                "final_score": r.final_score,
                "notes": r.notes,
            }
            for r in script_result.results
        ],
    }
    _save_result(result)

    return result


@app.get("/results")
def list_results():
    if not RESULTS_DIR.exists():
        return []
    summaries = []
    for path in RESULTS_DIR.glob("*.json"):
        with open(path) as f:
            r = json.load(f)
        summaries.append({
            "result_id": r["result_id"],
            "student_id": r["student_id"],
            "exam_id": r["exam_id"],
            "graded_at": r["graded_at"],
            "total_score": r["total_score"],
            "max_possible_score": r["max_possible_score"],
            "pending_review_count": r["pending_review_count"],
        })
    summaries.sort(key=lambda s: s["graded_at"], reverse=True)
    return summaries


@app.get("/results/{result_id}")
def get_result(result_id: str):
    result = _load_result(result_id)
    if result is None:
        raise HTTPException(status_code=404, detail=f"No stored result with id '{result_id}'")
    return result


@app.post("/results/{result_id}/review")
def review_item(result_id: str, update: ReviewUpdate):
    result = _load_result(result_id)
    if result is None:
        raise HTTPException(status_code=404, detail=f"No stored result with id '{result_id}'")

    question = next((q for q in result["questions"] if q["question_id"] == update.question_id), None)
    if question is None:
        raise HTTPException(
            status_code=400, detail=f"No question '{update.question_id}' in this result"
        )

    question["final_score"] = update.corrected_score
    question["reviewed"] = True
    question["flagged_for_review"] = False
    if update.corrected_text is not None:
        question["recognized_text"] = update.corrected_text

    result["total_score"] = sum(
        (q["final_score"] if q["final_score"] is not None else q["score"]) for q in result["questions"]
    )
    result["pending_review_count"] = sum(1 for q in result["questions"] if q["flagged_for_review"])

    _save_result(result)
    return result
