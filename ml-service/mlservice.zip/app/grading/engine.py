"""
Grading engine (Iteration 5).

Rules, matching your Chapter 3 design spec:
  - MCQ: exact match against the answer key -> full marks or zero.
  - Short phrase: similarity match (best match against any acceptable
    phrasing) -> proportional score.
  - Regardless of type: if the recognition model's confidence for that
    response falls below `confidence_threshold`, the item is flagged for
    human review instead of being scored automatically. A flagged item's
    suggested score is still computed and shown to the lecturer, but it is
    NOT counted toward the final total until confirmed/corrected.
"""
from dataclasses import dataclass, field
from typing import Dict, List, Optional

from rapidfuzz import fuzz


@dataclass
class QuestionResult:
    question_id: str
    type: str  # "mcq" or "phrase"
    recognized_text: str
    confidence: float
    score: float
    max_score: float
    flagged_for_review: bool
    reviewed: bool = False
    final_score: Optional[float] = None
    notes: str = ""


@dataclass
class ScriptResult:
    student_id: Optional[str]
    answer_key_id: str
    results: List[QuestionResult] = field(default_factory=list)

    @property
    def total_score(self) -> float:
        """Only counts items that are either not flagged, or flagged AND
        already reviewed/confirmed. Un-reviewed flagged items are excluded
        from the running total so a script can't be silently finalised with
        unresolved uncertain answers baked in."""
        total = 0.0
        for r in self.results:
            if r.flagged_for_review and not r.reviewed:
                continue
            total += r.final_score if r.final_score is not None else r.score
        return total

    @property
    def max_possible_score(self) -> float:
        return sum(r.max_score for r in self.results)

    @property
    def pending_review_count(self) -> int:
        return sum(1 for r in self.results if r.flagged_for_review and not r.reviewed)


def score_mcq(recognized_letter: str, correct_letter: str, max_score: float) -> float:
    """Exact-match scoring for multiple-choice. Case-insensitive, whitespace-trimmed."""
    if recognized_letter.strip().upper() == correct_letter.strip().upper():
        return max_score
    return 0.0


def score_phrase(recognized_text: str, acceptable_answers: List[str], max_score: float) -> float:
    """Similarity-based scoring for short phrases: take the BEST similarity
    ratio against any acceptable phrasing, then scale that ratio (0-100) onto
    max_score. Uses rapidfuzz's token_sort_ratio, which is robust to minor
    word-order/spacing differences (e.g. 'hash map' vs 'map hash') while
    still penalising genuinely different answers."""
    if not acceptable_answers:
        return 0.0

    recognized_clean = recognized_text.strip().lower()
    best_ratio = max(
        fuzz.token_sort_ratio(recognized_clean, ans.strip().lower())
        for ans in acceptable_answers
    )
    return round((best_ratio / 100.0) * max_score, 2)


def grade_script(
    recognized_answers: Dict[str, Dict],
    answer_key: dict,
    student_id: Optional[str] = None,
) -> ScriptResult:
    """
    recognized_answers: {question_id: {"text": str, "confidence": float}}
        (for mcq questions, "text" is the single recognised letter)
    answer_key: parsed contents of an answer_key_*.json file (see
        data/answer_key_example.json for the expected shape)
    """
    threshold = answer_key["confidence_threshold"]
    max_mcq = answer_key["max_score_mcq"]
    max_phrase = answer_key["max_score_phrase"]

    script_result = ScriptResult(student_id=student_id, answer_key_id=answer_key["answer_key_id"])

    for q_id, q_key in answer_key["answers"].items():
        recognized = recognized_answers.get(q_id)
        if recognized is None:
            # No recognition result at all for this question (e.g. segmentation
            # failed to find it) — treat as needing review with zero score.
            script_result.results.append(QuestionResult(
                question_id=q_id, type=q_key["type"], recognized_text="",
                confidence=0.0, score=0.0, max_score=(max_mcq if q_key["type"] == "mcq" else max_phrase),
                flagged_for_review=True, notes="No recognition result available.",
            ))
            continue

        text = recognized["text"]
        confidence = recognized["confidence"]

        if q_key["type"] == "mcq":
            max_score = max_mcq
            score = score_mcq(text, q_key["answer"], max_score)
        else:
            max_score = max_phrase
            score = score_phrase(text, q_key["acceptable_answers"], max_score)

        flagged = confidence < threshold

        script_result.results.append(QuestionResult(
            question_id=q_id,
            type=q_key["type"],
            recognized_text=text,
            confidence=confidence,
            score=score,
            max_score=max_score,
            flagged_for_review=flagged,
            notes="Below confidence threshold — needs lecturer review." if flagged else "",
        ))

    return script_result


def apply_review(script_result: ScriptResult, question_id: str, corrected_score: float, corrected_text: Optional[str] = None) -> None:
    """Called when a lecturer confirms/corrects a flagged item via the review
    dashboard. Marks the item reviewed and locks in the final score."""
    for r in script_result.results:
        if r.question_id == question_id:
            r.reviewed = True
            r.final_score = corrected_score
            if corrected_text is not None:
                r.recognized_text = corrected_text
            return
    raise ValueError(f"Question '{question_id}' not found in script result.")
